'''
Author: wangding wangding19@mails.ucas.ac.cn
Date: 2023-02-13 09:15:07
LastEditors: wangding wangding19@mails.ucas.ac.cn
LastEditTime: 2023-02-13 09:17:31
FilePath: \Leetcode_Solver\8.字符串转换整数-atoi.py
Description: 

Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
'''
#
# @lc app=leetcode.cn id=8 lang=python3
#
# [8] 字符串转换整数 (atoi)
#

# @lc code=start
class Solution:
    def myAtoi(self, s: str) -> int:
        uniqueelem = '1234567890+-'
        res = ''
        for i in range(len(s)):
            if s[i] in uniqueelem:
            
            elif :
                
# @lc code=end

