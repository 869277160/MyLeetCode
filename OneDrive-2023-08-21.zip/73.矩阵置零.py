'''
Author: wangding wangding19@mails.ucas.ac.cn
Date: 2023-03-11 17:53:05
LastEditors: wangding wangding19@mails.ucas.ac.cn
LastEditTime: 2023-03-11 17:55:06
FilePath: \Leetcode_Solver\73.矩阵置零.py
Description: 

Copyright (c) 2023 by ${git_name_email}, All Rights Reserved. 
'''
#
# @lc app=leetcode.cn id=73 lang=python3
#
# [73] 矩阵置零
#

# @lc code=start
# class Solution:
#     def setZeroes(self, matrix: List[List[int]]) -> None:
#         """
#         Do not return anything, modify matrix in-place instead.
#         """
        
#         new_matrix = [[1]*len(matrix[0])] *len(matrix)
        
#         for i in range(len(matrix)):
#             if 0 in matrix[i]:
#                 new_matrix[i] =[1]*len(matrix[0])
        
        
# @lc code=end

