#
# @lc app=leetcode.cn id=114 lang=python3
#
# [114] 二叉树展开为链表
#

# @lc code=start
# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def flatten(self, root: Optional[TreeNode]) -> None:
        """
        Do not return anything, modify root in-place instead.
        """
        
        # if root == None :
        #     return 
        # else :
        #     if root.left == None and root.right == None:
        #         retyu
        #     else:
                
            
        
        #     # 借鉴前序遍历思路
        #     root_node = root 
        #     left_node = root.left 
        #     right_node = root.right 

        #     flatten_left = self.flatten(left_node)
        #     flatten_right = self.flatten(right_node)
            
            
        #     root_node.left = None 
        #     root.right = flatten_left
            
        #     # flatten_left.right = flatten_right
        

        
        
        
        
# @lc code=end

