#
# @lc app=leetcode.cn id=43 lang=python3
#
# [43] 字符串相乘
#

# @lc code=start
class Solution:
    def multiply(self, num1: str, num2: str) -> str:
        # res = ""
        
        # p1, p2 = len(num1)-1, len(nums2)-1
        
        # while()
        
        
        # for 
    
    

        
        
        
        
        
# @lc code=end

